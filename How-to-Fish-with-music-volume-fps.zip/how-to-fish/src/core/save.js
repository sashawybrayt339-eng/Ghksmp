const KEY='how-to-fish-save-v1';
export const defaultSave=()=>({coins:120,caught:[],inventory:{worm:5},owned:['starter_rod'],equippedRod:'starter_rod',biome:'lake',quality:'auto',tutorialDone:false,casts:0,totalCaught:0,settings:{sound:true,particles:true,musicVolume:0.45,fpsEnabled:false}});
export function loadSave(){try{const raw=localStorage.getItem(KEY);if(!raw)return defaultSave();const s={...defaultSave(),...JSON.parse(raw)};s.inventory={...defaultSave().inventory,...s.inventory};s.settings={...defaultSave().settings,...s.settings};return s}catch{return defaultSave()}}
export function saveGame(data){try{localStorage.setItem(KEY,JSON.stringify(data));return true}catch(e){console.warn('Save unavailable',e);return false}}
export function resetSave(){localStorage.removeItem(KEY);return defaultSave()}
