import {MeshBuilder,StandardMaterial,Color3,Vector3,ShaderMaterial,Texture} from 'https://cdn.babylonjs.com/babylon.js';
export function createWater(scene){
 const water=MeshBuilder.CreateGround('water',{width:700,height:700,subdivisions:100},scene);water.position.y=0;
 const mat=new StandardMaterial('waterMat',scene);mat.diffuseColor=new Color3(.025,.27,.36);mat.specularColor=new Color3(.65,.85,.92);mat.specularPower=96;mat.alpha=.91;mat.backFaceCulling=false;
 // Animated procedural ripples are cheap enough to keep active on mobile.
 mat.emissiveColor=new Color3(.005,.045,.06);water.material=mat;water.isPickable=false;
 water.metadata={update(t){const p=mat.diffuseColor;const glow=.02+Math.sin(t*.22)*.008;mat.emissiveColor.set(glow,glow*4,glow*5)}};
 return water;
}
