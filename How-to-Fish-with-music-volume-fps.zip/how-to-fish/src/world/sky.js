import {MeshBuilder,StandardMaterial,Color3,Vector3,HemisphericLight,DirectionalLight} from 'https://cdn.babylonjs.com/babylon.js';
export function createSky(scene){
 scene.clearColor=new Color3(.48,.72,.86).toColor4(1);const hemi=new HemisphericLight('ambient',new Vector3(0,1,0),scene);hemi.intensity=.78;hemi.groundColor=new Color3(.18,.23,.27);
 const sun=new DirectionalLight('sun',new Vector3(-.45,-1,.35),scene);sun.position=new Vector3(80,120,-60);sun.intensity=1.15;
 const sky=MeshBuilder.CreateSphere('sky',{diameter:900,segments:16},scene);sky.isPickable=false;sky.infiniteDistance=true;sky.applyFog=false;
 const sm=new StandardMaterial('skyMat',scene);sm.backFaceCulling=false;sm.disableLighting=true;sm.emissiveColor=new Color3(.23,.51,.69);sm.diffuseColor=new Color3(.23,.51,.69);sky.material=sm;
 return {hemi,sun,sky,update(hour,weather){const a=(hour/24)*Math.PI*2-Math.PI/2;sun.direction=new Vector3(Math.cos(a)*-.7,-Math.max(.12,Math.sin(a)),.35).normalize();sun.intensity=.12+Math.max(0,Math.sin(a))*1.35;hemi.intensity=.22+Math.max(0,Math.sin(a))*.65;const night=Math.max(0,1-(sun.intensity/.8));sm.emissiveColor=new Color3(.025+sun.intensity*.18,.045+sun.intensity*.36,.10+sun.intensity*.42);scene.fogMode=weather==='fog'?1:0;scene.fogDensity=.0025;scene.fogColor=new Color3(.58,.69,.72)}};
}
