precision highp float; varying vec3 vDirection; uniform vec3 topColor; uniform vec3 horizonColor; uniform float sunHeight;
void main(){float h=clamp(normalize(vDirection).y*.5+.5,0.0,1.0);vec3 sky=mix(horizonColor,topColor,pow(h,.65));float sun=pow(max(dot(normalize(vDirection),normalize(vec3(.4,sunHeight,.2))),0.0),140.0);gl_FragColor=vec4(sky+vec3(1.0,.72,.42)*sun,1.0);}
