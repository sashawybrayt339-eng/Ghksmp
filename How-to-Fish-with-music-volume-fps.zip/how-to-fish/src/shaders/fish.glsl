precision highp float; varying vec3 vNormal; varying vec2 vUV; uniform vec3 fishColor;
void main(){float light=.45+.55*max(dot(normalize(vNormal),normalize(vec3(.4,.8,.3))),0.0);float stripe=step(.48,fract(vUV.x*7.0));gl_FragColor=vec4(fishColor*light*(.94+.06*stripe),1.0);}
