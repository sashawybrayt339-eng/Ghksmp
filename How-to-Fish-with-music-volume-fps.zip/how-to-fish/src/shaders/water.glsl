// Reference fragment shader for a future ShaderMaterial variant; the live build uses StandardMaterial for broad mobile compatibility.
precision highp float; varying vec2 vUV; uniform float time; uniform vec3 baseColor;
void main(){vec2 uv=vUV;float w=sin(uv.x*38.0+time*1.3)*cos(uv.y*29.0-time*.9);float ripple=pow(max(0.0,1.0-abs(w)),4.0);gl_FragColor=vec4(baseColor+vec3(.04,.11,.14)*ripple,0.94);}
