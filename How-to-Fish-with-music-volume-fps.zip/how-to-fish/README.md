# How to Fish — mobile 3D fishing simulator

A no-build ES-module browser game using Babylon.js 7.x from the official CDN. Run it from a static web server or deploy the folder to a static host. Browsers block ES module `fetch()` and service workers from `file://`, so opening `index.html` directly may not load game data or PWA caching.

## Run
- Upload the entire folder to any HTTPS static host, or use a local static server such as `python -m http.server 8080` from this directory.
- Open the served URL, then press **Start Fishing**.
- Left virtual stick steers the boat; drag the scene to look/aim; pinch to zoom; CAST throws the bobber; REEL starts/continues a catch; BAG opens collection and SHOP opens upgrades.
- Settings let you switch lake/river/ocean/arctic and choose auto/low/medium/high/ultra graphics.

## Project layout
- `index.html`, `style.css`, `manifest.json`, `service-worker.js`
- `src/main.js`: engine, scene, loop, game state and UI wiring
- `src/core`: local save and quality presets
- `src/world`: procedural sky and animated water surface
- `src/entities`: boat, fish school, bobber
- `src/systems`: touch input and fishing state machine
- `src/ui`: inventory, shop, encyclopedia and settings
- `src/data`: 12 species plus items, biomes and quests
- `src/shaders`: GLSL reference shader snippets

## Technical notes
- Uses custom lightweight boat motion and bobber gravity so it runs without downloading a large physics runtime. Havok is not required by this implementation; boat and bobber motion are deterministic gameplay approximations, not a full rigid-body simulation.
- The scene is intentionally stylized and procedural: the water shader snippets, HDRI, CloudProceduralTexture, reflection probe, caustics, LUT, volumetric clouds, and skeletal fish rigs are not enabled in this lightweight no-build version. Shader files are reference snippets and are not wired as live ShaderMaterial effects. Avoid assuming photorealistic rendering from these starter assets.
- Fish are procedural meshes and a lightweight flock-like steering system, rather than external CC0 assets. This avoids unreliable third-party asset URLs and extra downloads.
- Babylon.js and browser APIs need network access on first load. The service worker caches local project files after a successful online visit; the Babylon CDN itself is not mirrored into the cache.
- Quality presets adjust hardware scaling, shadow state and active fish count. A 60 FPS target depends on device/browser and cannot be guaranteed across all phones.

## License / asset note
Game source written for this project. No third-party model assets are bundled. Babylon.js is loaded from its public CDN; check its current license and terms for your deployment.
